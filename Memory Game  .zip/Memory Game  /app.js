// event listener that will wait for an event to happen before starting the function 
document.addEventListener('DOMContentLoaded', () => {

    //card options 

    const cardArray = [
        {
            name: 'apples',
            img: 'images/apple.jpg'
        },
        {
            name: 'apples', 
            img: 'images/apple.jpg'
        },
        {
            name: 'Comet',
            img: 'images/Comet.png'
        },
        {
            name: 'Comet',
            img: 'images/Comet.png'
        },
        {
            name: 'bananas',
            img: 'images/banana.png'
        },
        {
            name: 'bananas',
            img: 'images/banana.png'
        },
        {
            name: 'spinach',
            img: 'images/spinach.png'
        },
        {
            name: 'spinach',
            img: 'images/spinach.png'
        },
        {
            name: 'camera',
            img: 'images/camera.png'
        },
        {
            name: 'camera',
            img: 'images/camera.png'
        },
        {
            name: 'ice cream',
            img: 'images/iceCream.png'

        },
        {
            name: 'ice cream',
            img: 'images/iceCream.png'

        }
    ]
    
    //randomizes our code by 'sorting' and Math.random 
    cardArray.sort(( ) => 0.5 - Math.random())

    // defining grid for our html 
    const grid = document.querySelector('.grid')
    const resultDisplay = document.querySelector('#result')
    var cardsChosen = []
    var cardsChosenId = [] 
    var cardsWon = [] 


    // creating our board :) 
    function createBoard() {
                // creating for loop that allows us to go through the list of images/food items for our grid 
        for (let i = 0; i < cardArray.length; i++) {
            var card = document.createElement('img')
            card.setAttribute('src', 'images/cardback.jpeg')
            card.setAttribute('data-id', i )
                //the event listener waits for our cards to clicked.  
            card.addEventListener('click', flipCard)
            grid.appendChild(card)
        }
    }
    
    // check for matches
   function checkForMatch () {
        var cards = document.querySelectorAll('img')
        const optionOneId = cardsChosenId[0]
        const optionTwoId = cardsChosenId[1]
        if (cardsChosen[0] === cardsChosen[1]) {
            alert('You found a match')
            cards[optionOneId].setAttribute('src', 'images/download.png')
            cards[optionTwoId].setAttribute('src', 'images/download.png')
            cards[optionOneId].removeEventListener("click", flipCard); 
            cards[optionTwoId].removeEventListener("click", flipCard);
            cardsWon.push(cardsChosen) 
        } else {
            cards[optionOneId].setAttribute('src', 'images/cardback.jpeg')
            cards[optionTwoId].setAttribute('src', 'images/cardback.jpeg')
            alert('Sorry, try again')
        }
        cardsChosen = []
        cardsChosenId = []
        resultDisplay.textContent = cardsWon.length
        if (cardsWon.length === cardArray.length/2) {
            resultDisplay.textContent = 'Congradulations! You found them all'
        }
    }
    
    // flip your card 
    function flipCard() {
        var cardId = this.getAttribute('data-id')
        cardsChosen.push(cardArray[cardId].name) //locates id
        cardsChosenId.push(cardId) 
        this.setAttribute('src', cardArray[cardId].img)
        if (cardsChosen.length === 2 ) {
            setTimeout(checkForMatch, 500)
        }
    }
    createBoard();
}) 

