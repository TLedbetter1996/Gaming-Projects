//1.) Learn more detail on for loops 
//2.) JQUERY selector 
//3.) Learn/use arrays 
//4.) Java functionality 
// append child